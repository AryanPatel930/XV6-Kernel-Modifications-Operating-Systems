#ifndef THREAD_H
#define THREAD_H

//define our thread library function prototypes
int thread_create(void (*function)(void*), void * arg);
int thread_join(int threadid);

#endif  
