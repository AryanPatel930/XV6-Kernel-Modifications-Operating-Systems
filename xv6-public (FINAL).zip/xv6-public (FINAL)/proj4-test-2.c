#include "types.h"
#include "user.h"
#include "stat.h"
#include "thread.h"

/*
	Project 4: Main program 2:
	Define a global array of integers,
	Pass a function to a thread which modifies the corresponding array
	with a specific incremental value
	
	Result: your final array should reflect all changes in the corresponding
	threads created
*/

int arr[20];

void function(void * arg)
{
	int num = *((int*)arg);
	for(int i = 0; i < 5; i++)
	{
		arr[num + i] = num;
	}
	
	exit();
}

int main(int argc, char * argv[])
{
	int threadids[4];
	
	int num0 = 0;
	int num1 = 5;
	int num2 = 10;
	int num3 = 15;
	
	threadids[0] = thread_create(&function, &num0);
	threadids[1] = thread_create(&function, &num1);
	threadids[2] = thread_create(&function, &num2);
	threadids[3] = thread_create(&function, &num3);
	
	for(int i = 0; i < 4; i++)
	{
		thread_join(threadids[i]);
	}
	
	for(int i = 0; i < 20; i++)
	{
		printf(1, "[%d]: %d\n", i, arr[i]);
	}
	
	exit();
}
