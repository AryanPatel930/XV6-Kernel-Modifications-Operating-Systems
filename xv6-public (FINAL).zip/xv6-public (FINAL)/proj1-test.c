#include "types.h"
#include "user.h"
#include "fcntl.h"

int main(void) {
    reset_file_open_count(); // Reset the counter at the start
    printf(1, "Counter after reset: %d\n", get_file_open_count());

    int fd1 = open("proj1-f1.txt", O_RDONLY);
    if (fd1 < 0) {
        printf(1, "Failed to open proj1-f1.txt\n");
    } else {
        printf(1, "Counter after opening proj1-f1.txt: %d\n", get_file_open_count());
    }

    int fd2 = open("proj1-f2.txt", O_RDONLY);
    if (fd2 < 0) {
        printf(1, "Failed to open proj1-f2.txt\n");
    } else {
        printf(1, "Counter after opening proj1-f2.txt: %d\n", get_file_open_count());
    }

    int fd3 = open("proj1-f3.txt", O_RDONLY);
    if (fd3 < 0) {
        printf(1, "Failed to open proj1-f3.txt\n");
    } else {
        printf(1, "Counter after opening proj1-f3.txt: %d\n", get_file_open_count());
    }

    // Close files only if they were successfully opened
    if (fd1 >= 0) close(fd1);
    if (fd2 >= 0) close(fd2);
    if (fd3 >= 0) close(fd3);

    // Final counter check
    int count = get_file_open_count();
    if (count == 3) {
        printf(1, "Success!\n");
    } else {
        printf(1, "File Counter Incorrect");
    }
    exit();
}

