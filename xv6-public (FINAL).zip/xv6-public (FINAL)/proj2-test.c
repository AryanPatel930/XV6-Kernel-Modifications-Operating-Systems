#include "types.h"
#include "user.h"
#include "rand.h"

void spin() {
    volatile int sink = 0;
    while (1) {
        sink += 3;
    }
}

int main(int argc, char *argv[]) {
    int tickets[] = {100, 200, 300};
    int pids[3];
    int rc;
    
  
    
    for (int i = 0; i < 3; i++) {
        rc = fork();
        if (rc == 0) {
            settickets(tickets[i]);
            exit();  // Child process exits immediately after setting tickets
        } else if (rc > 0) {
            pids[i] = rc;
        } else {
            printf(2, "Fork failed.\n");
            exit();
        }
    }
    
    settickets(10);
    printf(1, "Parent:\nPID = %d\nTickets = %d\n", getpid(), 10);
    sleep(5000);
    
    for (int i = 0; i < 3; ++i) {
        kill(pids[i]);
    }
    
    
    for (int i = 0; i < 3; ++i) {
        wait();
    }
    
    exit();
}

